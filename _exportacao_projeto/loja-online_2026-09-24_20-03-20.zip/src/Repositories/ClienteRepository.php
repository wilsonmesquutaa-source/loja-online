<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;
use PDOException;
use RuntimeException;

final class ClienteRepository
{
    private PDO $pdo;


    public function __construct(
        PDO $pdo
    ) {
        $this->pdo = $pdo;
    }


    /*
    =================================
    VERIFICA E-MAIL
    =================================
    */

    public function emailExiste(
        string $email
    ): bool {

        $sql = "
            SELECT id
            FROM clientes
            WHERE email = :email
            LIMIT 1
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':email' =>
                $email,
        ]);


        return
            $stmt->fetch(
                PDO::FETCH_ASSOC
            ) !== false;
    }


    /*
    =================================
    VERIFICA E-MAIL DE OUTRO CLIENTE
    =================================
    */

    public function emailExisteParaOutroCliente(
        string $email,
        int $clienteId
    ): bool {

        $sql = "
            SELECT id
            FROM clientes
            WHERE email = :email
            AND id <> :id
            LIMIT 1
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':email' =>
                $email,

            ':id' =>
                $clienteId,
        ]);


        return
            $stmt->fetch(
                PDO::FETCH_ASSOC
            ) !== false;
    }


    /*
    =================================
    BUSCA POR E-MAIL
    =================================
    */

    public function buscarPorEmail(
        string $email
    ): ?array {

        $sql = "
            SELECT
                id,
                google_sub,
                nome,
                email,
                senha_hash,
                foto_url,
                email_verificado,
                ultimo_acesso,
                criado_em,
                atualizado_em
            FROM clientes
            WHERE email = :email
            LIMIT 1
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':email' =>
                $email,
        ]);


        $cliente =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (
            $cliente === false
        ) {

            return null;
        }


        return $cliente;
    }


    /*
    =================================
    BUSCA POR GOOGLE SUB
    =================================
    */

    public function buscarPorGoogleSub(
        string $googleSub
    ): ?array {

        $sql = "
            SELECT
                id,
                google_sub,
                nome,
                email,
                senha_hash,
                foto_url,
                email_verificado,
                ultimo_acesso,
                criado_em,
                atualizado_em
            FROM clientes
            WHERE google_sub = :google_sub
            LIMIT 1
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':google_sub' =>
                $googleSub,
        ]);


        $cliente =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (
            $cliente === false
        ) {

            return null;
        }


        return $cliente;
    }


    /*
    =================================
    BUSCA POR ID
    =================================
    */

    public function buscarPorId(
        int $id
    ): ?array {

        $sql = "
            SELECT
                id,
                google_sub,
                nome,
                email,
                senha_hash,
                foto_url,
                email_verificado,
                ultimo_acesso,
                criado_em,
                atualizado_em
            FROM clientes
            WHERE id = :id
            LIMIT 1
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':id' =>
                $id,
        ]);


        $cliente =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (
            $cliente === false
        ) {

            return null;
        }


        return $cliente;
    }


    /*
    =================================
    ATUALIZA DADOS DO CLIENTE
    =================================
    */

    public function atualizarDados(
        int $clienteId,
        string $nome,
        string $email
    ): void {

        $sql = "
            UPDATE clientes
            SET
                nome = :nome,
                email = :email
            WHERE id = :id
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':nome' =>
                $nome,

            ':email' =>
                $email,

            ':id' =>
                $clienteId,
        ]);
    }


    /*
    =================================
    ATUALIZA FOTO DO CLIENTE
    =================================
    */

    public function atualizarFoto(
        int $clienteId,
        ?string $fotoUrl
    ): void {

        $sql = "
            UPDATE clientes
            SET
                foto_url = :foto_url
            WHERE id = :id
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':foto_url' =>
                $fotoUrl,

            ':id' =>
                $clienteId,
        ]);
    }


    /*
    =================================
    CRIA CLIENTE TRADICIONAL
    =================================
    */

    public function criar(
        string $nome,
        string $email,
        string $senhaHash
    ): int {

        $sql = "
            INSERT INTO clientes (
                google_sub,
                nome,
                email,
                senha_hash,
                foto_url,
                email_verificado,
                ultimo_acesso
            )
            VALUES (
                NULL,
                :nome,
                :email,
                :senha_hash,
                NULL,
                0,
                NULL
            )
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':nome' =>
                $nome,

            ':email' =>
                $email,

            ':senha_hash' =>
                $senhaHash,
        ]);


        return
            (int)
            $this->pdo->lastInsertId();
    }


    /*
    =================================
    CRIA CLIENTE GOOGLE
    =================================
    */

    public function criarComGoogle(
        string $googleSub,
        string $nome,
        string $email,
        ?string $fotoUrl,
        bool $emailVerificado
    ): int {

        $sql = "
            INSERT INTO clientes (
                google_sub,
                nome,
                email,
                senha_hash,
                foto_url,
                email_verificado,
                ultimo_acesso
            )
            VALUES (
                :google_sub,
                :nome,
                :email,
                NULL,
                :foto_url,
                :email_verificado,
                NOW()
            )
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        try {

            $stmt->execute([
                ':google_sub' =>
                    $googleSub,

                ':nome' =>
                    $nome,

                ':email' =>
                    $email,

                ':foto_url' =>
                    $fotoUrl,

                ':email_verificado' =>
                    $emailVerificado
                        ? 1
                        : 0,
            ]);

        } catch (
            PDOException $erro
        ) {

            throw new RuntimeException(
                'Não foi possível criar a conta Google.',
                0,
                $erro
            );
        }


        return
            (int)
            $this->pdo->lastInsertId();
    }


    /*
    =================================
    VINCULA GOOGLE À CONTA EXISTENTE
    =================================
    */

    public function vincularGoogle(
        int $clienteId,
        string $googleSub,
        ?string $fotoUrl,
        bool $emailVerificado
    ): void {

        $sql = "
            UPDATE clientes
            SET
                google_sub = :google_sub,
                foto_url = :foto_url,
                email_verificado = :email_verificado,
                ultimo_acesso = NOW()
            WHERE id = :id
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        try {

            $stmt->execute([
                ':google_sub' =>
                    $googleSub,

                ':foto_url' =>
                    $fotoUrl,

                ':email_verificado' =>
                    $emailVerificado
                        ? 1
                        : 0,

                ':id' =>
                    $clienteId,
            ]);

        } catch (
            PDOException $erro
        ) {

            throw new RuntimeException(
                'Não foi possível vincular a conta Google.',
                0,
                $erro
            );
        }
    }


    /*
    =================================
    CRIA TOKEN DE VERIFICAÇÃO
    =================================
    */

    public function criarTokenVerificacao(
        int $clienteId,
        string $tokenHash
    ): void {

        $sql = "
            UPDATE clientes
            SET
                token_verificacao_email = :token,
                token_verificacao_expira_em =
                    DATE_ADD(
                        UTC_TIMESTAMP(),
                        INTERVAL 1 HOUR
                    )
            WHERE id = :id
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':token' =>
                $tokenHash,

            ':id' =>
                $clienteId,
        ]);
    }


    /*
    =================================
    BUSCA CLIENTE PELO TOKEN
    =================================

    Aqui procuramos somente pelo hash.
    A validade é verificada separadamente
    pelo Controller.
    */

    public function buscarPorTokenVerificacao(
        string $tokenHash
    ): ?array {

        $sql = "
            SELECT
                id,
                nome,
                email,
                foto_url,
                email_verificado,
                token_verificacao_expira_em
            FROM clientes
            WHERE token_verificacao_email = :token
            LIMIT 1
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':token' =>
                $tokenHash,
        ]);


        $cliente =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (
            $cliente === false
        ) {

            return null;
        }


        return $cliente;
    }


    /*
    =================================
    CONFIRMA E-MAIL
    =================================
    */

    public function verificarEmail(
        int $clienteId
    ): void {

        $sql = "
            UPDATE clientes
            SET
                email_verificado = 1,
                token_verificacao_email = NULL,
                token_verificacao_expira_em = NULL,
                ultimo_acesso = NOW()
            WHERE id = :id
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':id' =>
                $clienteId,
        ]);
    }


    /*
    =================================
    ATUALIZA E-MAIL
    =================================
    */

    public function atualizarEmail(
        int $clienteId,
        string $email
    ): void {

        $sql = "
            UPDATE clientes
            SET
                email = :email
            WHERE id = :id
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':email' =>
                $email,

            ':id' =>
                $clienteId,
        ]);
    }


    /*
    =================================
    ATUALIZA SENHA
    =================================
    */

    public function atualizarSenha(
        int $clienteId,
        string $senhaHash
    ): void {

        $sql = "
            UPDATE clientes
            SET
                senha_hash = :senha_hash
            WHERE id = :id
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':senha_hash' =>
                $senhaHash,

            ':id' =>
                $clienteId,
        ]);
    }


    /*
    =================================
    VERIFICA PEDIDOS
    =================================
    */

    public function possuiPedidos(
        int $clienteId
    ): bool {

        $sql = "
            SELECT id
            FROM pedidos
            WHERE cliente_id = :cliente_id
            LIMIT 1
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':cliente_id' =>
                $clienteId,
        ]);


        return
            $stmt->fetch(
                PDO::FETCH_ASSOC
            ) !== false;
    }


    /*
    =================================
    EXCLUI CONTA SEM PEDIDOS
    =================================
    */

    public function excluirConta(
        int $clienteId
    ): void {

        $this->pdo->beginTransaction();


        try {

            $stmt =
                $this->pdo->prepare(
                    "
                    DELETE FROM dispositivos_notificacao
                    WHERE cliente_id = :cliente_id
                    "
                );


            $stmt->execute([
                ':cliente_id' =>
                    $clienteId,
            ]);


            $stmt =
                $this->pdo->prepare(
                    "
                    DELETE FROM enderecos
                    WHERE cliente_id = :cliente_id
                    "
                );


            $stmt->execute([
                ':cliente_id' =>
                    $clienteId,
            ]);


            $stmt =
                $this->pdo->prepare(
                    "
                    DELETE FROM carrinhos
                    WHERE cliente_id = :cliente_id
                    "
                );


            $stmt->execute([
                ':cliente_id' =>
                    $clienteId,
            ]);


            $stmt =
                $this->pdo->prepare(
                    "
                    DELETE FROM clientes
                    WHERE id = :cliente_id
                    "
                );


            $stmt->execute([
                ':cliente_id' =>
                    $clienteId,
            ]);


            $this->pdo->commit();

        } catch (
            \Throwable $erro
        ) {

            if (
                $this->pdo->inTransaction()
            ) {

                $this->pdo->rollBack();
            }


            throw $erro;
        }
    }


    /*
    =================================
    ENCERRA CONTA COM PEDIDOS
    =================================
    */

    public function anonimizarConta(
        int $clienteId
    ): void {

        $this->pdo->beginTransaction();


        try {

            $emailAnonimo =
                'conta-excluida-'
                . $clienteId
                . '@local.invalid';


            $stmt =
                $this->pdo->prepare(
                    "
                    UPDATE clientes
                    SET
                        google_sub = NULL,
                        nome = 'Conta excluída',
                        email = :email,
                        senha_hash = NULL,
                        foto_url = NULL,
                        email_verificado = 0,
                        token_verificacao_email = NULL,
                        token_verificacao_expira_em = NULL
                    WHERE id = :id
                    "
                );


            $stmt->execute([
                ':email' =>
                    $emailAnonimo,

                ':id' =>
                    $clienteId,
            ]);


            $stmt =
                $this->pdo->prepare(
                    "
                    DELETE FROM dispositivos_notificacao
                    WHERE cliente_id = :cliente_id
                    "
                );


            $stmt->execute([
                ':cliente_id' =>
                    $clienteId,
            ]);


            $stmt =
                $this->pdo->prepare(
                    "
                    DELETE FROM enderecos
                    WHERE cliente_id = :cliente_id
                    "
                );


            $stmt->execute([
                ':cliente_id' =>
                    $clienteId,
            ]);


            $stmt =
                $this->pdo->prepare(
                    "
                    DELETE FROM carrinhos
                    WHERE cliente_id = :cliente_id
                    "
                );


            $stmt->execute([
                ':cliente_id' =>
                    $clienteId,
            ]);


            $this->pdo->commit();

        } catch (
            \Throwable $erro
        ) {

            if (
                $this->pdo->inTransaction()
            ) {

                $this->pdo->rollBack();
            }


            throw $erro;
        }
    }


    /*
    =================================
    ATUALIZA ÚLTIMO ACESSO
    =================================
    */

    public function atualizarUltimoAcesso(
        int $clienteId
    ): void {

        $sql = "
            UPDATE clientes
            SET
                ultimo_acesso = NOW()
            WHERE id = :id
        ";


        $stmt =
            $this->pdo->prepare(
                $sql
            );


        $stmt->execute([
            ':id' =>
                $clienteId,
        ]);
    }
}