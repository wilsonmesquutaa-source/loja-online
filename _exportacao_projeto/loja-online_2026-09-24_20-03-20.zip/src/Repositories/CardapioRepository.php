<?php

declare(strict_types=1);

namespace App\Repositories;

use PDO;

final class CardapioRepository
{
    private PDO $pdo;


    public function __construct(
        PDO $pdo
    ) {
        $this->pdo = $pdo;
    }


    /*
    =================================
    TODAS AS CATEGORIAS
    =================================
    */

    public function buscarCategorias(): array
    {
        $sql = '
            SELECT
                categorias.id,
                categorias.nome,
                categorias.slug,
                categorias.descricao,
                categorias.preco,
                categorias.preco_revenda,
                categorias.quantidade_minima_revenda,

                (
                    SELECT
                        categoria_imagens.url_imagem
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_url,

                (
                    SELECT
                        categoria_imagens.posicao_x
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_x,

                (
                    SELECT
                        categoria_imagens.posicao_y
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_y,
(
                    SELECT
                        categoria_imagens.escala
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_escala

            FROM categorias

            WHERE categorias.ativo = 1

            ORDER BY
                categorias.ordem_destaque ASC,
                categorias.id ASC
        ';


        $consulta =
            $this->pdo->prepare(
                $sql
            );


        $consulta->execute();


        return
            $consulta->fetchAll();
    }


    /*
    =================================
    CATEGORIAS EM DESTAQUE
    =================================
    */

    public function buscarCategoriasDestaque(): array
    {
        $sql = '
            SELECT
                categorias.id,
                categorias.nome,
                categorias.slug,
                categorias.descricao,
                categorias.preco,
                categorias.preco_revenda,
                categorias.quantidade_minima_revenda,

                (
                    SELECT
                        categoria_imagens.url_imagem
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_url,

                (
                    SELECT
                        categoria_imagens.posicao_x
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_x,

                (
                    SELECT
                        categoria_imagens.posicao_y
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_y,
(
                    SELECT
                        categoria_imagens.escala
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_escala

            FROM categorias

            WHERE categorias.ativo = 1
            AND categorias.destaque = 1

            ORDER BY
                categorias.ordem_destaque ASC,
                categorias.id ASC
        ';


        $consulta =
            $this->pdo->prepare(
                $sql
            );


        $consulta->execute();


        return
            $consulta->fetchAll();
    }


    /*
    =================================
    DESTAQUES DA HOME
    =================================
    */

    public function buscarDestaquesHome(): array
    {
        $sql = '
            SELECT
                destaques_home.id AS destaque_id,
                destaques_home.tipo,
                destaques_home.item_id,
                destaques_home.ordem,

                categorias.id AS categoria_id,
                categorias.nome AS categoria_nome,
                categorias.slug AS categoria_slug,
                categorias.descricao AS categoria_descricao,
                categorias.preco,
                categorias.preco_revenda,
                categorias.quantidade_minima_revenda,

                NULL AS produto_id,
                NULL AS produto_nome,
                NULL AS produto_descricao,

                (
                    SELECT
                        categoria_imagens.url_imagem
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_url,

                (
                    SELECT
                        categoria_imagens.posicao_x
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_x,

                (
                    SELECT
                        categoria_imagens.posicao_y
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_y,
(
                    SELECT
                        categoria_imagens.escala
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_escala

            FROM destaques_home

            INNER JOIN categorias
                ON categorias.id =
                    destaques_home.item_id

            WHERE destaques_home.tipo = :tipo_categoria
            AND destaques_home.ativo = 1
            AND categorias.ativo = 1

            UNION ALL

            SELECT
                destaques_home.id AS destaque_id,
                destaques_home.tipo,
                destaques_home.item_id,
                destaques_home.ordem,

                categorias.id AS categoria_id,
                categorias.nome AS categoria_nome,
                categorias.slug AS categoria_slug,
                categorias.descricao AS categoria_descricao,
                categorias.preco,
                categorias.preco_revenda,
                categorias.quantidade_minima_revenda,

                produtos.id AS produto_id,
                produtos.nome AS produto_nome,
                produtos.descricao AS produto_descricao,

                (
                    SELECT
                        produto_imagens.url_imagem
                    FROM produto_imagens
                    WHERE produto_imagens.produto_id =
                        produtos.id
                    AND produto_imagens.principal = 1
                    ORDER BY
                        produto_imagens.ordem ASC,
                        produto_imagens.id ASC
                    LIMIT 1
                ) AS imagem_url,

                (
                    SELECT
                        produto_imagens.posicao_x
                    FROM produto_imagens
                    WHERE produto_imagens.produto_id =
                        produtos.id
                    AND produto_imagens.principal = 1
                    ORDER BY
                        produto_imagens.ordem ASC,
                        produto_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_x,

                (
                    SELECT
                        produto_imagens.posicao_y
                    FROM produto_imagens
                    WHERE produto_imagens.produto_id =
                        produtos.id
                    AND produto_imagens.principal = 1
                    ORDER BY
                        produto_imagens.ordem ASC,
                        produto_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_y,
(
                    SELECT
                        produto_imagens.escala
                    FROM produto_imagens
                    WHERE produto_imagens.produto_id =
                        produtos.id
                    AND produto_imagens.principal = 1
                    ORDER BY
                        produto_imagens.ordem ASC,
                        produto_imagens.id ASC
                    LIMIT 1
                ) AS imagem_escala

            FROM destaques_home

            INNER JOIN produtos
                ON produtos.id =
                    destaques_home.item_id

            INNER JOIN categorias
                ON categorias.id =
                    produtos.categoria_id

            WHERE destaques_home.tipo = :tipo_produto
            AND destaques_home.ativo = 1
            AND produtos.status = :status_produto
            AND categorias.ativo = 1

            ORDER BY
                ordem ASC,
                destaque_id ASC
        ';


        $consulta =
            $this->pdo->prepare(
                $sql
            );


        $consulta->bindValue(
            ':tipo_categoria',
            'categoria',
            PDO::PARAM_STR
        );


        $consulta->bindValue(
            ':tipo_produto',
            'produto',
            PDO::PARAM_STR
        );


        $consulta->bindValue(
            ':status_produto',
            'ativo',
            PDO::PARAM_STR
        );


        $consulta->execute();


        $destaques =
            $consulta->fetchAll();


        return
            $destaques;
    }


    /*
    =================================
    CATEGORIA POR ID
    =================================
    */

    public function buscarCategoriaPorId(
        int $categoriaId
    ): ?array {

        $sql = '
            SELECT
                categorias.id,
                categorias.nome,
                categorias.slug,
                categorias.descricao,
                categorias.preco,
                categorias.preco_revenda,
                categorias.quantidade_minima_revenda,

                (
                    SELECT
                        categoria_imagens.url_imagem
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_url,

                (
                    SELECT
                        categoria_imagens.posicao_x
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_x,

                (
                    SELECT
                        categoria_imagens.posicao_y
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_y,
(
                    SELECT
                        categoria_imagens.escala
                    FROM categoria_imagens
                    WHERE categoria_imagens.categoria_id =
                        categorias.id
                    AND categoria_imagens.principal = 1
                    ORDER BY
                        categoria_imagens.ordem ASC,
                        categoria_imagens.id ASC
                    LIMIT 1
                ) AS imagem_escala

            FROM categorias

            WHERE categorias.id = :id
            AND categorias.ativo = 1

            LIMIT 1
        ';


        $consulta =
            $this->pdo->prepare(
                $sql
            );


        $consulta->bindValue(
            ':id',
            $categoriaId,
            PDO::PARAM_INT
        );


        $consulta->execute();


        $categoria =
            $consulta->fetch();


        return
            $categoria !== false
            ? $categoria
            : null;
    }


    /*
    =================================
    PRODUTOS POR CATEGORIA
    =================================
    */

    public function buscarProdutosPorCategoria(
        int $categoriaId
    ): array {

        $sql = '
            SELECT
                produtos.id,
                produtos.categoria_id,
                produtos.nome,
                produtos.descricao,
                produtos.estoque,

                (
                    SELECT
                        produto_imagens.url_imagem
                    FROM produto_imagens
                    WHERE produto_imagens.produto_id =
                        produtos.id
                    AND produto_imagens.principal = 1
                    ORDER BY
                        produto_imagens.ordem ASC,
                        produto_imagens.id ASC
                    LIMIT 1
                ) AS imagem_url,

                (
                    SELECT
                        produto_imagens.posicao_x
                    FROM produto_imagens
                    WHERE produto_imagens.produto_id =
                        produtos.id
                    AND produto_imagens.principal = 1
                    ORDER BY
                        produto_imagens.ordem ASC,
                        produto_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_x,

                (
                    SELECT
                        produto_imagens.posicao_y
                    FROM produto_imagens
                    WHERE produto_imagens.produto_id =
                        produtos.id
                    AND produto_imagens.principal = 1
                    ORDER BY
                        produto_imagens.ordem ASC,
                        produto_imagens.id ASC
                    LIMIT 1
                ) AS imagem_posicao_y,
(
                    SELECT
                        produto_imagens.escala
                    FROM produto_imagens
                    WHERE produto_imagens.produto_id =
                        produtos.id
                    AND produto_imagens.principal = 1
                    ORDER BY
                        produto_imagens.ordem ASC,
                        produto_imagens.id ASC
                    LIMIT 1
                ) AS imagem_escala

            FROM produtos

            WHERE produtos.categoria_id = :categoria_id
            AND produtos.status = :status

            ORDER BY
                produtos.nome
        ';


        $consulta =
            $this->pdo->prepare(
                $sql
            );


        $consulta->bindValue(
            ':categoria_id',
            $categoriaId,
            PDO::PARAM_INT
        );


        $consulta->bindValue(
            ':status',
            'ativo',
            PDO::PARAM_STR
        );


        $consulta->execute();


        return
            $consulta->fetchAll();
    }


    /*
    =================================
    BANNER DA CATEGORIA
    =================================
    */

    public function buscarBannerCategoriaPorId(
        int $categoriaId
    ): ?array {

        $sql = '
            SELECT
                categoria_banners.id,
                categoria_banners.categoria_id,
                categoria_banners.url_imagem,
                categoria_banners.texto_alternativo,
                categoria_banners.posicao_x,
                categoria_banners.posicao_y, categoria_banners.escala,
                categoria_banners.ativo

            FROM categoria_banners

            WHERE categoria_banners.categoria_id = :categoria_id
            AND categoria_banners.ativo = 1

            LIMIT 1
        ';


        $consulta =
            $this->pdo->prepare(
                $sql
            );


        $consulta->bindValue(
            ':categoria_id',
            $categoriaId,
            PDO::PARAM_INT
        );


        $consulta->execute();


        $banner =
            $consulta->fetch();


        return
            $banner !== false
            ? $banner
            : null;
    }
}